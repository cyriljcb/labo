#include "mainwindowex3.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindowEx3 w;
    w.show();
    return a.exec();
}

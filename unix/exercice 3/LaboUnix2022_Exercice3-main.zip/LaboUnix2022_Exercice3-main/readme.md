# Exercice 3 de "Système d'exploitation et Programmation Système UNIX"

Objectifs :
* Se familiariser avec la création de processus (fork, exec, exit et wait).
* Se familiariser avec l’utilisation de la librairie C d’accès à une base de données MySql.
* Création d’un fichier de traces.
* Et toujours : création d’un makefile


/********************************************************************************
** Form generated from reading UI file 'mainwindowex3.ui'
**
** Created by: Qt User Interface Compiler version 5.12.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWEX3_H
#define UI_MAINWINDOWEX3_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindowEx3
{
public:
    QWidget *centralwidget;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEditGroupe1;
    QLabel *label_3;
    QLineEdit *lineEditResultat1;
    QLabel *label_4;
    QLineEdit *lineEditResultat2;
    QLineEdit *lineEditGroupe2;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEditResultat3;
    QLineEdit *lineEditGroupe3;
    QLabel *label_8;
    QLabel *label_9;
    QPushButton *pushButtonLancerRecherche;
    QPushButton *pushButtonVider;
    QPushButton *pushButtonQuitter;
    QCheckBox *checkBoxRecherche1;
    QCheckBox *checkBoxRecherche2;
    QCheckBox *checkBoxRecherche3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindowEx3)
    {
        if (MainWindowEx3->objectName().isEmpty())
            MainWindowEx3->setObjectName(QString::fromUtf8("MainWindowEx3"));
        MainWindowEx3->resize(581, 363);
        centralwidget = new QWidget(MainWindowEx3);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 111, 17));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 50, 64, 21));
        lineEditGroupe1 = new QLineEdit(centralwidget);
        lineEditGroupe1->setObjectName(QString::fromUtf8("lineEditGroupe1"));
        lineEditGroupe1->setGeometry(QRect(100, 50, 171, 25));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(310, 50, 151, 21));
        lineEditResultat1 = new QLineEdit(centralwidget);
        lineEditResultat1->setObjectName(QString::fromUtf8("lineEditResultat1"));
        lineEditResultat1->setGeometry(QRect(470, 50, 91, 25));
        lineEditResultat1->setReadOnly(true);
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(310, 140, 151, 21));
        lineEditResultat2 = new QLineEdit(centralwidget);
        lineEditResultat2->setObjectName(QString::fromUtf8("lineEditResultat2"));
        lineEditResultat2->setGeometry(QRect(470, 140, 91, 25));
        lineEditResultat2->setReadOnly(true);
        lineEditGroupe2 = new QLineEdit(centralwidget);
        lineEditGroupe2->setObjectName(QString::fromUtf8("lineEditGroupe2"));
        lineEditGroupe2->setGeometry(QRect(100, 140, 171, 25));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(20, 110, 111, 17));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 140, 64, 21));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(310, 230, 151, 21));
        lineEditResultat3 = new QLineEdit(centralwidget);
        lineEditResultat3->setObjectName(QString::fromUtf8("lineEditResultat3"));
        lineEditResultat3->setGeometry(QRect(470, 230, 91, 25));
        lineEditResultat3->setReadOnly(true);
        lineEditGroupe3 = new QLineEdit(centralwidget);
        lineEditGroupe3->setObjectName(QString::fromUtf8("lineEditGroupe3"));
        lineEditGroupe3->setGeometry(QRect(100, 230, 171, 25));
        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 200, 111, 17));
        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 230, 64, 21));
        pushButtonLancerRecherche = new QPushButton(centralwidget);
        pushButtonLancerRecherche->setObjectName(QString::fromUtf8("pushButtonLancerRecherche"));
        pushButtonLancerRecherche->setGeometry(QRect(20, 290, 191, 25));
        pushButtonVider = new QPushButton(centralwidget);
        pushButtonVider->setObjectName(QString::fromUtf8("pushButtonVider"));
        pushButtonVider->setGeometry(QRect(240, 290, 83, 25));
        pushButtonQuitter = new QPushButton(centralwidget);
        pushButtonQuitter->setObjectName(QString::fromUtf8("pushButtonQuitter"));
        pushButtonQuitter->setGeometry(QRect(450, 290, 111, 25));
        checkBoxRecherche1 = new QCheckBox(centralwidget);
        checkBoxRecherche1->setObjectName(QString::fromUtf8("checkBoxRecherche1"));
        checkBoxRecherche1->setGeometry(QRect(130, 12, 121, 31));
        checkBoxRecherche2 = new QCheckBox(centralwidget);
        checkBoxRecherche2->setObjectName(QString::fromUtf8("checkBoxRecherche2"));
        checkBoxRecherche2->setGeometry(QRect(130, 100, 121, 31));
        checkBoxRecherche3 = new QCheckBox(centralwidget);
        checkBoxRecherche3->setObjectName(QString::fromUtf8("checkBoxRecherche3"));
        checkBoxRecherche3->setGeometry(QRect(130, 190, 121, 31));
        MainWindowEx3->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindowEx3);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 581, 22));
        MainWindowEx3->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindowEx3);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindowEx3->setStatusBar(statusbar);

        retranslateUi(MainWindowEx3);

        QMetaObject::connectSlotsByName(MainWindowEx3);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowEx3)
    {
        MainWindowEx3->setWindowTitle(QApplication::translate("MainWindowEx3", "UNIX_Exercice3", nullptr));
        label->setText(QApplication::translate("MainWindowEx3", "<html><head/><body><p><span style=\" font-weight:600; color:#204a87;\">Recherche 1 :</span></p></body></html>", nullptr));
        label_2->setText(QApplication::translate("MainWindowEx3", "Groupe :", nullptr));
        label_3->setText(QApplication::translate("MainWindowEx3", "Nombre d'\303\251tudiants :", nullptr));
        label_4->setText(QApplication::translate("MainWindowEx3", "Nombre d'\303\251tudiants :", nullptr));
        label_5->setText(QApplication::translate("MainWindowEx3", "<html><head/><body><p><span style=\" font-weight:600; color:#204a87;\">Recherche 2 :</span></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("MainWindowEx3", "Groupe :", nullptr));
        label_7->setText(QApplication::translate("MainWindowEx3", "Nombre d'\303\251tudiants :", nullptr));
        label_8->setText(QApplication::translate("MainWindowEx3", "<html><head/><body><p><span style=\" font-weight:600; color:#204a87;\">Recherche 3 :</span></p></body></html>", nullptr));
        label_9->setText(QApplication::translate("MainWindowEx3", "Groupe :", nullptr));
        pushButtonLancerRecherche->setText(QApplication::translate("MainWindowEx3", "Lancer la recherche", nullptr));
        pushButtonVider->setText(QApplication::translate("MainWindowEx3", "Vider", nullptr));
        pushButtonQuitter->setText(QApplication::translate("MainWindowEx3", "Quitter", nullptr));
        checkBoxRecherche1->setText(QString());
        checkBoxRecherche2->setText(QString());
        checkBoxRecherche3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindowEx3: public Ui_MainWindowEx3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWEX3_H

/****************************************************************************
** Meta object code from reading C++ file 'applicgaragewindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "applicgaragewindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'applicgaragewindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ApplicGarageWindow_t {
    QByteArrayData data[24];
    char stringdata0[815];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ApplicGarageWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ApplicGarageWindow_t qt_meta_stringdata_ApplicGarageWindow = {
    {
QT_MOC_LITERAL(0, 0, 18), // "ApplicGarageWindow"
QT_MOC_LITERAL(1, 19, 33), // "on_actionNouveau_modele_trigg..."
QT_MOC_LITERAL(2, 53, 0), // ""
QT_MOC_LITERAL(3, 54, 34), // "on_actionNouvelle_option_trig..."
QT_MOC_LITERAL(4, 89, 34), // "on_pushButtonChoisirModele_cl..."
QT_MOC_LITERAL(5, 124, 34), // "on_pushButtonAjouterOption_cl..."
QT_MOC_LITERAL(6, 159, 36), // "on_pushButtonSupprimerOption_..."
QT_MOC_LITERAL(7, 196, 30), // "on_pushButtonReduction_clicked"
QT_MOC_LITERAL(8, 227, 33), // "on_actionAjouterEmploye_trigg..."
QT_MOC_LITERAL(9, 261, 46), // "on_actionSupprimerEmploye_par..."
QT_MOC_LITERAL(10, 308, 45), // "on_actionSupprimerEmploye_sel..."
QT_MOC_LITERAL(11, 354, 32), // "on_actionAjouterClient_triggered"
QT_MOC_LITERAL(12, 387, 45), // "on_actionSupprimerClient_par_..."
QT_MOC_LITERAL(13, 433, 44), // "on_actionSupprimerClient_sele..."
QT_MOC_LITERAL(14, 478, 24), // "on_actionLogin_triggered"
QT_MOC_LITERAL(15, 503, 26), // "on_actionQuitter_triggered"
QT_MOC_LITERAL(16, 530, 34), // "on_pushButtonNouveauProjet_cl..."
QT_MOC_LITERAL(17, 565, 33), // "on_pushButtonOuvrirProjet_cli..."
QT_MOC_LITERAL(18, 599, 38), // "on_pushButtonEnregistrerProje..."
QT_MOC_LITERAL(19, 638, 25), // "on_actionLogout_triggered"
QT_MOC_LITERAL(20, 664, 37), // "on_actionReset_Mot_de_passe_t..."
QT_MOC_LITERAL(21, 702, 35), // "on_pushButtonNouveauContrat_c..."
QT_MOC_LITERAL(22, 738, 37), // "on_pushButtonSupprimerContrat..."
QT_MOC_LITERAL(23, 776, 38) // "on_pushButtonVisualiserVoitur..."

    },
    "ApplicGarageWindow\0on_actionNouveau_modele_triggered\0"
    "\0on_actionNouvelle_option_triggered\0"
    "on_pushButtonChoisirModele_clicked\0"
    "on_pushButtonAjouterOption_clicked\0"
    "on_pushButtonSupprimerOption_clicked\0"
    "on_pushButtonReduction_clicked\0"
    "on_actionAjouterEmploye_triggered\0"
    "on_actionSupprimerEmploye_par_numero_triggered\0"
    "on_actionSupprimerEmploye_selection_triggered\0"
    "on_actionAjouterClient_triggered\0"
    "on_actionSupprimerClient_par_numero_triggered\0"
    "on_actionSupprimerClient_selection_triggered\0"
    "on_actionLogin_triggered\0"
    "on_actionQuitter_triggered\0"
    "on_pushButtonNouveauProjet_clicked\0"
    "on_pushButtonOuvrirProjet_clicked\0"
    "on_pushButtonEnregistrerProjet_clicked\0"
    "on_actionLogout_triggered\0"
    "on_actionReset_Mot_de_passe_triggered\0"
    "on_pushButtonNouveauContrat_clicked\0"
    "on_pushButtonSupprimerContrat_clicked\0"
    "on_pushButtonVisualiserVoiture_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ApplicGarageWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x08 /* Private */,
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    0,  127,    2, 0x08 /* Private */,
       6,    0,  128,    2, 0x08 /* Private */,
       7,    0,  129,    2, 0x08 /* Private */,
       8,    0,  130,    2, 0x08 /* Private */,
       9,    0,  131,    2, 0x08 /* Private */,
      10,    0,  132,    2, 0x08 /* Private */,
      11,    0,  133,    2, 0x08 /* Private */,
      12,    0,  134,    2, 0x08 /* Private */,
      13,    0,  135,    2, 0x08 /* Private */,
      14,    0,  136,    2, 0x08 /* Private */,
      15,    0,  137,    2, 0x08 /* Private */,
      16,    0,  138,    2, 0x08 /* Private */,
      17,    0,  139,    2, 0x08 /* Private */,
      18,    0,  140,    2, 0x08 /* Private */,
      19,    0,  141,    2, 0x08 /* Private */,
      20,    0,  142,    2, 0x08 /* Private */,
      21,    0,  143,    2, 0x08 /* Private */,
      22,    0,  144,    2, 0x08 /* Private */,
      23,    0,  145,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ApplicGarageWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ApplicGarageWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_actionNouveau_modele_triggered(); break;
        case 1: _t->on_actionNouvelle_option_triggered(); break;
        case 2: _t->on_pushButtonChoisirModele_clicked(); break;
        case 3: _t->on_pushButtonAjouterOption_clicked(); break;
        case 4: _t->on_pushButtonSupprimerOption_clicked(); break;
        case 5: _t->on_pushButtonReduction_clicked(); break;
        case 6: _t->on_actionAjouterEmploye_triggered(); break;
        case 7: _t->on_actionSupprimerEmploye_par_numero_triggered(); break;
        case 8: _t->on_actionSupprimerEmploye_selection_triggered(); break;
        case 9: _t->on_actionAjouterClient_triggered(); break;
        case 10: _t->on_actionSupprimerClient_par_numero_triggered(); break;
        case 11: _t->on_actionSupprimerClient_selection_triggered(); break;
        case 12: _t->on_actionLogin_triggered(); break;
        case 13: _t->on_actionQuitter_triggered(); break;
        case 14: _t->on_pushButtonNouveauProjet_clicked(); break;
        case 15: _t->on_pushButtonOuvrirProjet_clicked(); break;
        case 16: _t->on_pushButtonEnregistrerProjet_clicked(); break;
        case 17: _t->on_actionLogout_triggered(); break;
        case 18: _t->on_actionReset_Mot_de_passe_triggered(); break;
        case 19: _t->on_pushButtonNouveauContrat_clicked(); break;
        case 20: _t->on_pushButtonSupprimerContrat_clicked(); break;
        case 21: _t->on_pushButtonVisualiserVoiture_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject ApplicGarageWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_ApplicGarageWindow.data,
    qt_meta_data_ApplicGarageWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ApplicGarageWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ApplicGarageWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ApplicGarageWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int ApplicGarageWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
